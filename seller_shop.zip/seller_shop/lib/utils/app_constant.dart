import 'dart:ui';

class AppConstant {
  static String appName = "E Commerce";
  static const appPrimaryColor = Color(0xFFbf1b08);
  static const appSecondPrimaryColor = Color(0xFF981206);
  static const appTextColor = Color(0xFFFBF5F4);
  static const appStatusBarColor = Color(0xFFFBF5F4);
}